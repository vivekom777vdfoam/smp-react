import React, {Component} from 'react';
import ReactDOM from 'react-dom';

export default class Home extends Component {
  render () {
    return (
      <div>
        <div className="container">
          <h1>Home page</h1>
        </div>
      </div>
    );
  }
}
