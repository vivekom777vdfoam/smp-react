import React, {Component} from 'react';

export default class Footer extends Component {
  render () {
    return (
      <footer className="footer">
        <div className="container text-center">
          <p>&copy; All Rights Reserved <a href="javascript:void(0);">Privacy Policy</a></p>
        </div>
      </footer>
    );
  }
}
