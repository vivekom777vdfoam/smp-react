# CarsHome

## Installation

````sh
npm install
````

## Usage

To run `npm run dev` for local environment:

````sh
npm run dev
````
You can view the site at [`http://localhost:8080`](http://localhost:8080).
